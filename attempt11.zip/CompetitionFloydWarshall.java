import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

/*
 * A Contest to Meet (ACM) is a reality TV contest that sets three contestants at three random
 * city intersections. In order to win, the three contestants need all to meet at any intersection
 * of the city as fast as possible.
 * It should be clear that the contestants may arrive at the intersections at different times, in
 * which case, the first to arrive can wait until the others arrive.
 * From an estimated walking speed for each one of the three contestants, ACM wants to determine the
 * minimum time that a live TV broadcast should last to cover their journey regardless of the contestantsâ€™
 * initial positions and the intersection they finally meet. You are hired to help ACM answer this question.
 * You may assume the following:
 *    ï‚· Each contestant walks at a given estimated speed.
 *    ï‚· The city is a collection of intersections in which some pairs are connected by one-way
 * streets that the contestants can use to traverse the city.
 *
 * This class implements the competition using Floyd-Warshall algorithm
 */

/**
 * @author Hannah Keating
 *
 */

public class CompetitionFloydWarshall {
	double contestASpeed;
	double contestBSpeed;
	double contestCSpeed;
	double slowestSpeed;
	int nodeNum;
	int edgeNum;
	double[][] distanceTable;
	double inf = Double.POSITIVE_INFINITY;

	/**
	 * @param filename:
	 *            A filename containing the details of the city road network
	 * @param sA,
	 *            sB, sC: speeds for 3 contestants
	 * @throws IOException
	 * 
	 *             Purpose: Constructor
	 */
	CompetitionFloydWarshall(String filename, int sA, int sB, int sC) {
		contestASpeed = sA;
		contestBSpeed = sB;
		contestCSpeed = sC;

		slowestSpeed = contestASpeed;
		if (contestBSpeed < slowestSpeed) {
			slowestSpeed = contestBSpeed;
		}
		if (contestCSpeed < slowestSpeed) {
			slowestSpeed = contestCSpeed;
		}

		distanceTable = null;
		if (filename != null) {
			processTextFile(filename);
		}
	}

	/**
	 * @param filename:
	 *            A filename containing the details of the city road network
	 * @throws IOException
	 * 
	 *             Purpose: This function process the test files and creates the
	 *             distanceTable. It process the to, from and weights.
	 */
	public void processTextFile(String filename) {
		if (filename.equals("")) {
			nodeNum = 0;
			distanceTable = null;
			return;
		}
		try {
			BufferedReader bf = new BufferedReader(new FileReader(filename));
			nodeNum = Integer.parseInt(bf.readLine());
			edgeNum = Integer.parseInt(bf.readLine());

			String fileString;
			fileString = bf.readLine();
			distanceTable = new double[nodeNum][nodeNum];

			for (int i = 0; i < nodeNum; i++)
			{
				for (int j = 0; j < nodeNum; j++) {
					distanceTable[i][j] = inf;
					if (i == j) {
						distanceTable[i][i] = 0;
					}

				}
			}

			while (fileString !=null) {
				String[] stringArray = fileString.trim().split("\\s+");
				int startNode = Integer.parseInt(stringArray[0]) ;
				int endNode = Integer.parseInt(stringArray[1]) ;
				double weight =Double.parseDouble(stringArray[2]); 
				weight = weight * 1000;
				weight = weight / slowestSpeed;
				distanceTable[startNode][endNode] = weight;
				fileString = bf.readLine();
			}
			bf.close(); 
			return; 
		}
		catch(NumberFormatException | IOException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}


	/**
	 * @return int: minimum minutes that will pass before the three contestants can
	 *         meet
	 * 
	 *         Purpose: Calculates minimum minutes.
	 */

	public int timeRequiredforCompetition() {
		int timeRequired = -1;

		if (nodeNum == 0) {
			return timeRequired;
		}

		if (contestASpeed < 50 || contestASpeed > 100 || contestBSpeed < 50 || contestBSpeed > 100
				|| contestCSpeed > 100 || contestCSpeed < 50) {
			return timeRequired;
		}
		distanceTable = floydWarshall(distanceTable);
		timeRequired = getSlowestTime(distanceTable);
		return timeRequired;
	}

	/**
	 * @param dist:
	 *            A 2D double array of the distances in meters
	 * 
	 *            Purpose: Calculates the Shortest distance from all nodes in the
	 *            graph to each other.
	 */
	public double[][] floydWarshall(double[][] dist) {
		for (int k = 0; k < nodeNum; k++) {
			for (int i = 0; i < nodeNum; i++) {
				for (int j = 0; j < nodeNum; j++) {
					if (dist[i][j] > dist[i][k] + dist[k][j]) {
						dist[i][j] = dist[i][k] + dist[k][j];
					}
				}
			}
		}
		return dist;
	}

	/**
	 * @param slowestContestTimeChart:
	 *            A 2D double array of the time it takes the slowest persons to walk
	 *            to any node.
	 * @return int of maximum time taken
	 * 
	 *         Purpose: Finds the largest period of time that the slowest person
	 *         will to walk to any point in the city. If we find inf, we return -1.
	 */
	public int getSlowestTime(double[][] dist) {
		double slowestTime = dist[0][0];
		for (int i = 0; i < nodeNum; i++) {
			for (int j = 0; j < nodeNum; j++) {
				if (dist[i][j] == inf) {
					return -1;
				} else if (dist[i][j] > slowestTime) {
					slowestTime = dist[i][j];
				}
			}
		}
		if (slowestTime % 1 != 0) {
			slowestTime++;
		}
		int returnTimeInt = (int) slowestTime;
		return returnTimeInt;
	}
}