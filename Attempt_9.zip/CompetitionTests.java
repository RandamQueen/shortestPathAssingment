
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * @author Hannah Keating
 *
 *
 *Notes: 
 *
 *Unforunately, I wasn't able to decrease the memory cost of these algorithms. This was find in most cases, 
 *bar input-h, which had a heap overflow error. Unforunately, I wasn't able to resolve this in the time frame that I
 *had. 
 *Theory: 
 *	1. Justify the choice of the data structures used in CompetitionDijkstra and
	CompetitionFloydWarshall
	
		For CompetitionDijkstra, I used the Edge Weighted Graph data structure. This structure was used 
		as it allowed me to implement the queue that is very important to the testing order of this Sort Path 
		algorithms.  
		
		I chose to use the 2D double array for CompetitionFloydWarshall, as it mare the most sense 
		for what we where trying to create. That is, a table of the nodes, with the time taken to
		get from one node to another. This structure allowed use to implement Floyd Warshall and also
		gave us an easy way to find the longest possible time. 
	
	2. Explain theoretical differences in the performance of Dijkstra and Floyd-Warshall algorithms
	in the given problem. Also explain how would their relative performance be affected by the
	density of the graph. Which would you choose in which set of circumstances and why? 
	

	When implementing these algorithms, I assumed that it was the worst case scenario, so the number of 
	edge (E) equal the number of vertices squared(V^2). Dijkstra has a performance of  V^3 log V, but that's a lot of space. 
	Floyd-Warshall has a performance of V^3 but takes V^2 space. The affect of graph density also has an effect on perfomance. 
	For Floyd-Warshall, the amount of edges doens't affect on long it will take to run thought the graph, as it will always compare 
	V^3, due to it's 3 for loop structures. The number of edges will affect the performance of Dijkstra, as each edge added will 
	take more space and running time. 
	
	 If I had to pick which algorithms to use, I most often go for Floyd-Warshall. This is because it's running time is 
	 guarantee, it's going to be V^3, regardless of the number of edges their was in the graph. I would consider using Dijkstra,
	 if the number of edges was relatively low, as to avoid using too much memory. 
 *
 */
public class CompetitionTests {
	String tinyEWDText = "0 ->2 0.26\n" + "0 ->4 0.38\n" + "1 ->3 0.29\n" + "2 ->7 0.34\n" + "3 ->6 0.52\n"
			+ "4 ->5 0.35\n" + "4 ->7 0.37\n" + "5 ->7 0.35\n" + "5 ->4 0.35\n" + "6 ->2 0.4\n" + "6 ->0 0.58\n"
			+ "6 ->4 0.93\n" + "7 ->5 0.28\n" + "7 ->3 0.39\n";

	@Test
	public void testDijkstraConstructor() {
		String filename = "tinyEWD.txt";
		int contestantSpeed = 75;
		CompetitionDijkstra dijkstra = new CompetitionDijkstra(filename, contestantSpeed, contestantSpeed,
				contestantSpeed);
		dijkstra = new CompetitionDijkstra("", contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(dijkstra.contestGrapgh, null);

		dijkstra = new CompetitionDijkstra(null, contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(dijkstra.contestGrapgh, null);
	}

	@Test
	public void testTimeRequiredforCompetitionrD() {
		String filename = " ";
		int correctTestVal = -1;
		int result;

		CompetitionDijkstra dijkstra = new CompetitionDijkstra(filename, 49, 50, 90);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		filename = "tinyEWD.txt";
		dijkstra = new CompetitionDijkstra(filename, 49, 50, 90);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		dijkstra = new CompetitionDijkstra(filename, 50, 90, 101);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed above range

		dijkstra = new CompetitionDijkstra(filename, 50, 75, 100);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 38;
		assertEquals(correctTestVal, result); // returns correct time, when A is the slowest person

		filename = "1000EWD.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 28;
		assertEquals(correctTestVal, result); // returns correct time

		filename = "input-A.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = -1;
		assertEquals(correctTestVal, result); // returns -1	

		filename = "input-B.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 10000;
		assertEquals(correctTestVal, result); // returns 1000
		
		filename = "input-N.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 160;
		assertEquals(correctTestVal, result); // returns 1000
		
	}

	@Test
	public void testFWConstructor() {
		String filename = "tinyEWD.txt";
		int contestantSpeed = 50;

		CompetitionFloydWarshall floydWarshall = new CompetitionFloydWarshall(filename, contestantSpeed,
				contestantSpeed, contestantSpeed);

		floydWarshall = new CompetitionFloydWarshall("", contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(floydWarshall.distanceTable, null);

		floydWarshall = new CompetitionFloydWarshall(null, contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(floydWarshall.distanceTable, null);
	}

	@Test
	public void testTimeRequiredforCompetitionrFW() {
		String filename = "";
		int correctTestVal = -1;
		int result;

		CompetitionFloydWarshall floydWarshall = new CompetitionFloydWarshall(filename, 49, 50, 90);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as empty file string

		filename = "tinyEWD.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 49, 50, 90);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		floydWarshall = new CompetitionFloydWarshall(filename, 50, 90, 101);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed above range

		floydWarshall = new CompetitionFloydWarshall(filename, 50, 75, 100);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = 38;
		assertEquals(correctTestVal, result); // returns correct time, when A is the slowest person

		floydWarshall = new CompetitionFloydWarshall(filename, 75, 50, 100);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns correct time, when B is the slowest person

		floydWarshall = new CompetitionFloydWarshall(filename, 75, 90, 50);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns correct time, when B is the slowest person

		filename = "1000EWD.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 50, 50, 50);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = 28;
		assertEquals(correctTestVal, result); // returns correct time

		filename = "input-B.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 50, 50, 50);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = 10000;
		assertEquals(correctTestVal, result); // returns correct time
		
		filename = "input-A.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 50, 50, 50);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = -1;
		assertEquals(correctTestVal, result); // returns correct time
	}
}
