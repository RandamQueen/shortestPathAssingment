
import java.io.File;
import java.io.FileNotFoundException;

import java.io.IOException;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

/*
 * A Contest to Meet (ACM) is a reality TV contest that sets three contestants at three random
 * city intersections. In order to win, the three contestants need all to meet at any intersection
 * of the city as fast as possible.
 * 
 * It should be clear that the contestants may arrive at the intersections at different times, in
 * which case, the first to arrive can wait until the others arrive.
 * 
 * From an estimated walking speed for each one of the three contestants, ACM wants to determine the
 * minimum time that a live TV broadcast should last to cover their journey regardless of the contestantsâ€™
 * initial positions and the intersection they finally meet. You are hired to help ACM answer this question.
 * You may assume the following:
 * 
 *    ï‚· Each contestant walks at a given estimated speed.
 *    ï‚· The city is a collection of intersections in which some pairs are connected by one-way
 * streets that the contestants can use to traverse the city.
 *
 * This class implements the competition using Dijkstra's algorithm
 */

/**
 * @author Hannah Keating
 *
 */

public class CompetitionDijkstra {
	double contestASpeed;
	double contestBSpeed;
	double contestCSpeed;
	double slowestSpeed;

	int nodeNum;
	int edgeNum;

	EdgeWeightedGraph contestGrapgh;

	double inf = Double.POSITIVE_INFINITY;

	/**
	 * @param filename:
	 *            A filename containing the details of the city road network
	 * @param sA,
	 *            sB, sC: speeds for 3 contestants
	 * @throws IOException
	 * 
	 *             Purpose: Constructor
	 */
	CompetitionDijkstra(String filename, int sA, int sB, int sC) {
		contestASpeed = sA;
		contestBSpeed = sB;
		contestCSpeed = sC;

		slowestSpeed = contestASpeed;
		if (contestBSpeed < slowestSpeed) {
			slowestSpeed = contestBSpeed;
		}
		if (contestCSpeed < slowestSpeed) {
			slowestSpeed = contestCSpeed;
		}
		if (filename != null) {
			processTextFile(filename);
		}
	}

	/**
	 * @param filename:
	 *            A filename containing the details of the city road network
	 * @throws IOException
	 * @throws IOException
	 * 
	 *             Purpose: This function process the text files and creates the
	 *             contestGraph and adds the edges to this graph.
	 */

	public void processTextFile(String filename) {
		if (filename.equals("")) {
			nodeNum = 0;
			contestGrapgh = null;
			return;
		}

		Scanner fileScanner;
		try {
			fileScanner = new Scanner(new File(filename));

			nodeNum = fileScanner.nextInt();
			edgeNum = fileScanner.nextInt();

			contestGrapgh = new EdgeWeightedGraph(nodeNum);

			while (fileScanner.hasNextLine()) {
				if (fileScanner.hasNextInt()) {
					int startNode = fileScanner.nextInt();
					int endNode = fileScanner.nextInt();
					double weight = fileScanner.nextDouble();

					weight = weight * 1000;
					weight = weight / slowestSpeed;

					DirectedEdge newEdge = new DirectedEdge(startNode, endNode, weight);
					contestGrapgh.addEdge(newEdge);
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return int: minimum minutes that will pass before the three contestants can
	 *         meet
	 * 
	 *         Purpose: Calculates minimum minutes.
	 */
	public int timeRequiredforCompetition() {
		int timeRequired = -1;
		if (nodeNum == 0) {
			return timeRequired;
		}
		if (contestASpeed < 50 || contestASpeed > 100 || contestBSpeed < 50 || contestBSpeed > 100
				|| contestCSpeed > 100 || contestCSpeed < 50) {
			return timeRequired;
		}

		DijkstraAllPairsSP shortestPath = new DijkstraAllPairsSP(contestGrapgh);
		double[][] nodeDistList = new double[nodeNum][nodeNum];
		for (int i = 0; i < nodeNum; i++) {
			for (int j = 0; j < nodeNum; j++) {
				nodeDistList[i][j] = shortestPath.dist(i, j);
			}
		}
		timeRequired = getSlowestTime(nodeDistList);
		return timeRequired;
	}

	/**
	 * @param slowestContestTimeChart:
	 *            A 2D double array of the time it takes the slowest persons to walk
	 *            to any node.
	 * @return int of maximum time taken
	 * 
	 *         Purpose: Finds the largest period of time that the slowest person
	 *         will to walk to any point in the city.
	 */
	public int getSlowestTime(double[][] dist) {
		double slowestTime = dist[0][0];
		for (int i = 0; i < nodeNum; i++) {
			for (int j = 0; j < nodeNum; j++) {
				if (dist[i][j] == inf) {
					return -1;
				}

				if (dist[i][j] > slowestTime) {
					slowestTime = dist[i][j];
				}
			}
		}
		if (slowestTime % 1 != 0) {
			slowestTime++;
		}
		int returnTimeInt = (int) slowestTime;
		return returnTimeInt;
	}

	public class DijkstraAllPairsSP {
		private DijkstraSP[] all;

		public DijkstraAllPairsSP(EdgeWeightedGraph G) {
			all = new DijkstraSP[G.V()];
			for (int v = 0; v < G.V(); v++)
				all[v] = new DijkstraSP(G, v);
		}

		public Iterable<DirectedEdge> path(int s, int t) {
			validateVertex(s);
			validateVertex(t);
			return all[s].pathTo(t);
		}

		public boolean hasPath(int s, int t) {
			validateVertex(s);
			validateVertex(t);
			return dist(s, t) < Double.POSITIVE_INFINITY;
		}

		public double dist(int s, int t) {
			validateVertex(s);
			validateVertex(t);
			return all[s].distTo(t);
		}

		// throw an IllegalArgumentException unless {@code 0 <= v < V}
		private void validateVertex(int v) {
			int V = all.length;
			if (v < 0 || v >= V)
				throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
		}
	}

	public class DijkstraSP {
		private double[] distTo; // distTo[v] = distance of shortest s->v path
		private DirectedEdge[] edgeTo; // edgeTo[v] = last edge on shortest s->v path
		private IndexMinPQ<Double> pq; // priority queue of vertices

		public DijkstraSP(EdgeWeightedGraph G, int s) {
			for (DirectedEdge e : G.edges()) {
				if (e.weight() < 0)
					throw new IllegalArgumentException("edge " + e + " has negative weight");
			}

			distTo = new double[G.V()];
			edgeTo = new DirectedEdge[G.V()];

			validateVertex(s);

			for (int v = 0; v < G.V(); v++)
				distTo[v] = Double.POSITIVE_INFINITY;
			distTo[s] = 0.0;

			// relax vertices in order of distance from s
			pq = new IndexMinPQ<Double>(G.V());
			pq.insert(s, distTo[s]);
			while (!pq.isEmpty()) {
				int v = pq.delMin();
				for (DirectedEdge e : G.adj(v))
					relax(e);
			}

			// check optimality conditions
			assert check(G, s);
		}

		// relax edge e and update pq if changed
		private void relax(DirectedEdge e) {
			int v = e.from(), w = e.to();
			if (distTo[w] > distTo[v] + e.weight()) {
				distTo[w] = distTo[v] + e.weight();
				edgeTo[w] = e;
				if (pq.contains(w))
					pq.decreaseKey(w, distTo[w]);
				else
					pq.insert(w, distTo[w]);
			}
		}

		public double distTo(int v) {
			validateVertex(v);
			return distTo[v];
		}

		public boolean hasPathTo(int v) {
			validateVertex(v);
			return distTo[v] < Double.POSITIVE_INFINITY;
		}

		public Iterable<DirectedEdge> pathTo(int v) {
			validateVertex(v);
			if (!hasPathTo(v))
				return null;
			Stack<DirectedEdge> path = new Stack<DirectedEdge>();
			for (DirectedEdge e = edgeTo[v]; e != null; e = edgeTo[e.from()]) {
				path.push(e);
			}
			return path;
		}

		// check optimality conditions:
		// (i) for all edges e: distTo[e.to()] <= distTo[e.from()] + e.weight()
		// (ii) for all edge e on the SPT: distTo[e.to()] == distTo[e.from()] +
		// e.weight()
		private boolean check(EdgeWeightedGraph G, int s) {

			// check that edge weights are nonnegative
			for (DirectedEdge e : G.edges()) {
				if (e.weight() < 0) {
					System.err.println("negative edge weight detected");
					return false;
				}
			}

			// check that distTo[v] and edgeTo[v] are consistent
			if (distTo[s] != 0.0 || edgeTo[s] != null) {
				System.err.println("distTo[s] and edgeTo[s] inconsistent");
				return false;
			}
			for (int v = 0; v < G.V(); v++) {
				if (v == s)
					continue;
				if (edgeTo[v] == null && distTo[v] != Double.POSITIVE_INFINITY) {
					System.err.println("distTo[] and edgeTo[] inconsistent");
					return false;
				}
			}

			// check that all edges e = v->w satisfy distTo[w] <= distTo[v] + e.weight()
			for (int v = 0; v < G.V(); v++) {
				for (DirectedEdge e : G.adj(v)) {
					int w = e.to();
					if (distTo[v] + e.weight() < distTo[w]) {
						System.err.println("edge " + e + " not relaxed");
						return false;
					}
				}
			}

			// check that all edges e = v->w on SPT satisfy distTo[w] == distTo[v] +
			// e.weight()
			for (int w = 0; w < G.V(); w++) {
				if (edgeTo[w] == null)
					continue;
				DirectedEdge e = edgeTo[w];
				int v = e.from();
				if (w != e.to())
					return false;
				if (distTo[v] + e.weight() != distTo[w]) {
					System.err.println("edge " + e + " on shortest path not tight");
					return false;
				}
			}
			return true;
		}

		// throw an IllegalArgumentException unless {@code 0 <= v < V}
		private void validateVertex(int v) {
			int V = distTo.length;
			if (v < 0 || v >= V)
				throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
		}
	}

	public class EdgeWeightedGraph {
		private final int V;
		private int E;
		private Bag<DirectedEdge>[] adj;

		public EdgeWeightedGraph(int V) {
			if (V < 0)
				throw new IllegalArgumentException("Number of vertices must be nonnegative");
			this.V = V;
			this.E = 0;
			adj = (Bag<DirectedEdge>[]) new Bag[V];
			for (int v = 0; v < V; v++) {
				adj[v] = new Bag<DirectedEdge>();
			}
		}

		public int V() {
			return V;
		}

		public int E() {
			return E;
		}

		private void validateVertex(int v) {
			if (v < 0 || v >= V)
				throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V - 1));
		}

		public void addEdge(DirectedEdge e) {
			int v = e.from();
			int w = e.to();
			validateVertex(v);
			validateVertex(w);
			adj[v].add(e);
			E++;
		}

		public Iterable<DirectedEdge> adj(int v) {
			validateVertex(v);
			return adj[v];
		}

		public int degree(int v) {
			validateVertex(v);
			return adj[v].size();
		}

		/**
		 * Returns all edges in this edge-weighted graph. To iterate over the edges in
		 * this edge-weighted graph, use foreach notation:
		 * {@code for (Edge e : G.edges())}.
		 *
		 * @return all edges in this edge-weighted graph, as an iterable
		 */
		public Iterable<DirectedEdge> edges() {
			Bag<DirectedEdge> list = new Bag<DirectedEdge>();
			for (int v = 0; v < V; v++) {
				int selfLoops = 0;
				for (DirectedEdge e : adj(v)) {
					if (e.to() > v) {
						list.add(e);
					}
					// add only one copy of each self loop (self loops will be consecutive)
					else if (e.to() == v) {
						if (selfLoops % 2 == 0)
							list.add(e);
						selfLoops++;
					}
				}
			}
			return list;
		}
	}

	public class Bag<Item> implements Iterable<Item> {
		private Node<Item> first; // beginning of bag
		private int n; // number of elements in bag

		// helper linked list class
		private class Node<Item> {
			private Item item;
			private Node<Item> next;
		}

		public Bag() {
			first = null;
			n = 0;
		}

		public boolean isEmpty() {
			return first == null;
		}

		public int size() {
			return n;
		}

		public void add(Item item) {
			Node<Item> oldfirst = first;
			first = new Node<Item>();
			first.item = item;
			first.next = oldfirst;
			n++;
		}

		public Iterator<Item> iterator() {
			return new ListIterator<Item>(first);
		}

		// an iterator, doesn't implement remove() since it's optional
		private class ListIterator<Item> implements Iterator<Item> {
			private Node<Item> current;

			public ListIterator(Node<Item> first) {
				current = first;
			}

			public boolean hasNext() {
				return current != null;
			}

			public void remove() {
				throw new UnsupportedOperationException();
			}

			public Item next() {
				if (!hasNext())
					throw new NoSuchElementException();
				Item item = current.item;
				current = current.next;
				return item;
			}
		}
	}

	public class DirectedEdge {
		private final int v;
		private final int w;
		private final double weight;

		public DirectedEdge(int v, int w, double weight) {
			this.v = v;
			this.w = w;
			this.weight = weight;
		}

		public int from() {
			return v;
		}

		public int to() {
			return w;
		}

		public double weight() {
			return weight;
		}
	}

	public class IndexMinPQ<Key extends Comparable<Key>> implements Iterable<Integer> {
	    private int maxN;        // maximum number of elements on PQ
	    private int n;           // number of elements on PQ
	    private int[] pq;        // binary heap using 1-based indexing
	    private int[] qp;        // inverse of pq - qp[pq[i]] = pq[qp[i]] = i
	    private Key[] keys;      // keys[i] = priority of i

	    /**
	     * Initializes an empty indexed priority queue with indices between {@code 0}
	     * and {@code maxN - 1}.
	     * @param  maxN the keys on this priority queue are index from {@code 0}
	     *         {@code maxN - 1}
	     * @throws IllegalArgumentException if {@code maxN < 0}
	     */
	    public IndexMinPQ(int maxN) {
	        if (maxN < 0) throw new IllegalArgumentException();
	        this.maxN = maxN;
	        n = 0;
	        keys = (Key[]) new Comparable[maxN + 1];    // make this of length maxN??
	        pq   = new int[maxN + 1];
	        qp   = new int[maxN + 1];                   // make this of length maxN??
	        for (int i = 0; i <= maxN; i++)
	            qp[i] = -1;
	    }

	    /**
	     * Returns true if this priority queue is empty.
	     *
	     * @return {@code true} if this priority queue is empty;
	     *         {@code false} otherwise
	     */
	    public boolean isEmpty() {
	        return n == 0;
	    }

	    /**
	     * Is {@code i} an index on this priority queue?
	     *
	     * @param  i an index
	     * @return {@code true} if {@code i} is an index on this priority queue;
	     *         {@code false} otherwise
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     */
	    public boolean contains(int i) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        return qp[i] != -1;
	    }

	    /**
	     * Returns the number of keys on this priority queue.
	     *
	     * @return the number of keys on this priority queue
	     */
	    public int size() {
	        return n;
	    }

	    /**
	     * Associates key with index {@code i}.
	     *
	     * @param  i an index
	     * @param  key the key to associate with index {@code i}
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws IllegalArgumentException if there already is an item associated
	     *         with index {@code i}
	     */
	    public void insert(int i, Key key) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (contains(i)) throw new IllegalArgumentException("index is already in the priority queue");
	        n++;
	        qp[i] = n;
	        pq[n] = i;
	        keys[i] = key;
	        swim(n);
	    }

	    /**
	     * Returns an index associated with a minimum key.
	     *
	     * @return an index associated with a minimum key
	     * @throws NoSuchElementException if this priority queue is empty
	     */
	    public int minIndex() {
	        if (n == 0) throw new NoSuchElementException("Priority queue underflow");
	        return pq[1];
	    }

	    /**
	     * Returns a minimum key.
	     *
	     * @return a minimum key
	     * @throws NoSuchElementException if this priority queue is empty
	     */
	    public Key minKey() {
	        if (n == 0) throw new NoSuchElementException("Priority queue underflow");
	        return keys[pq[1]];
	    }

	    /**
	     * Removes a minimum key and returns its associated index.
	     * @return an index associated with a minimum key
	     * @throws NoSuchElementException if this priority queue is empty
	     */
	    public int delMin() {
	        if (n == 0) throw new NoSuchElementException("Priority queue underflow");
	        int min = pq[1];
	        exch(1, n--);
	        sink(1);
	        assert min == pq[n+1];
	        qp[min] = -1;        // delete
	        keys[min] = null;    // to help with garbage collection
	        pq[n+1] = -1;        // not needed
	        return min;
	    }

	    /**
	     * Returns the key associated with index {@code i}.
	     *
	     * @param  i the index of the key to return
	     * @return the key associated with index {@code i}
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws NoSuchElementException no key is associated with index {@code i}
	     */
	    public Key keyOf(int i) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (!contains(i)) throw new NoSuchElementException("index is not in the priority queue");
	        else return keys[i];
	    }

	    /**
	     * Change the key associated with index {@code i} to the specified value.
	     *
	     * @param  i the index of the key to change
	     * @param  key change the key associated with index {@code i} to this key
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws NoSuchElementException no key is associated with index {@code i}
	     */
	    public void changeKey(int i, Key key) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (!contains(i)) throw new NoSuchElementException("index is not in the priority queue");
	        keys[i] = key;
	        swim(qp[i]);
	        sink(qp[i]);
	    }

	    /**
	     * Change the key associated with index {@code i} to the specified value.
	     *
	     * @param  i the index of the key to change
	     * @param  key change the key associated with index {@code i} to this key
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @deprecated Replaced by {@code changeKey(int, Key)}.
	     */
	    @Deprecated
	    public void change(int i, Key key) {
	        changeKey(i, key);
	    }

	    /**
	     * Decrease the key associated with index {@code i} to the specified value.
	     *
	     * @param  i the index of the key to decrease
	     * @param  key decrease the key associated with index {@code i} to this key
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws IllegalArgumentException if {@code key >= keyOf(i)}
	     * @throws NoSuchElementException no key is associated with index {@code i}
	     */
	    public void decreaseKey(int i, Key key) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (!contains(i)) throw new NoSuchElementException("index is not in the priority queue");
	        if (keys[i].compareTo(key) <= 0)
	            throw new IllegalArgumentException("Calling decreaseKey() with given argument would not strictly decrease the key");
	        keys[i] = key;
	        swim(qp[i]);
	    }

	    /**
	     * Increase the key associated with index {@code i} to the specified value.
	     *
	     * @param  i the index of the key to increase
	     * @param  key increase the key associated with index {@code i} to this key
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws IllegalArgumentException if {@code key <= keyOf(i)}
	     * @throws NoSuchElementException no key is associated with index {@code i}
	     */
	    public void increaseKey(int i, Key key) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (!contains(i)) throw new NoSuchElementException("index is not in the priority queue");
	        if (keys[i].compareTo(key) >= 0)
	            throw new IllegalArgumentException("Calling increaseKey() with given argument would not strictly increase the key");
	        keys[i] = key;
	        sink(qp[i]);
	    }

	    /**
	     * Remove the key associated with index {@code i}.
	     *
	     * @param  i the index of the key to remove
	     * @throws IllegalArgumentException unless {@code 0 <= i < maxN}
	     * @throws NoSuchElementException no key is associated with index {@code i}
	     */
	    public void delete(int i) {
	        if (i < 0 || i >= maxN) throw new IllegalArgumentException();
	        if (!contains(i)) throw new NoSuchElementException("index is not in the priority queue");
	        int index = qp[i];
	        exch(index, n--);
	        swim(index);
	        sink(index);
	        keys[i] = null;
	        qp[i] = -1;
	    }

	    private boolean greater(int i, int j) {
	        return keys[pq[i]].compareTo(keys[pq[j]]) > 0;
	    }

	    private void exch(int i, int j) {
	        int swap = pq[i];
	        pq[i] = pq[j];
	        pq[j] = swap;
	        qp[pq[i]] = i;
	        qp[pq[j]] = j;
	    }

	    private void swim(int k) {
	        while (k > 1 && greater(k/2, k)) {
	            exch(k, k/2);
	            k = k/2;
	        }
	    }

	    private void sink(int k) {
	        while (2*k <= n) {
	            int j = 2*k;
	            if (j < n && greater(j, j+1)) j++;
	            if (!greater(k, j)) break;
	            exch(k, j);
	            k = j;
	        }
	    }

	    public Iterator<Integer> iterator() { return new HeapIterator(); }

	    private class HeapIterator implements Iterator<Integer> {
	        // create a new pq
	        private IndexMinPQ<Key> copy;

	        // add all elements to copy of heap
	        // takes linear time since already in heap order so no keys move
	        public HeapIterator() {
	            copy = new IndexMinPQ<Key>(pq.length - 1);
	            for (int i = 1; i <= n; i++)
	                copy.insert(pq[i], keys[pq[i]]);
	        }

	        public boolean hasNext()  { return !copy.isEmpty();                     }
	        public void remove()      { throw new UnsupportedOperationException();  }

	        public Integer next() {
	            if (!hasNext()) throw new NoSuchElementException();
	            return copy.delMin();
	        }
	    }
	}
}