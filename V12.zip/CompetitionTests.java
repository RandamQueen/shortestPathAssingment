
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * @author Hannah Keating
 *
 */
public class CompetitionTests {
	String tinyEWDText = "0 ->2 0.26\n" + "0 ->4 0.38\n" + "1 ->3 0.29\n" + "2 ->7 0.34\n" + "3 ->6 0.52\n"
			+ "4 ->5 0.35\n" + "4 ->7 0.37\n" + "5 ->7 0.35\n" + "5 ->4 0.35\n" + "6 ->2 0.4\n" + "6 ->0 0.58\n"
			+ "6 ->4 0.93\n" + "7 ->5 0.28\n" + "7 ->3 0.39\n";

	@Test
	public void testDijkstraConstructor() {
		String filename = "tinyEWD.txt";
		int contestantSpeed = 75;
		CompetitionDijkstra dijkstra = new CompetitionDijkstra(filename, contestantSpeed, contestantSpeed,
				contestantSpeed);
		dijkstra = new CompetitionDijkstra("", contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(dijkstra.contestGrapgh, null);

		dijkstra = new CompetitionDijkstra(null, contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(dijkstra.contestGrapgh, null);
	}

	@Test
	public void testTimeRequiredforCompetitionrD() {
		String filename = " ";
		int correctTestVal = -1;
		int result;

		CompetitionDijkstra dijkstra = new CompetitionDijkstra(filename, 49, 50, 90);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		filename = "tinyEWD.txt";
		dijkstra = new CompetitionDijkstra(filename, 49, 50, 90);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		dijkstra = new CompetitionDijkstra(filename, 50, 90, 101);
		result = dijkstra.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed above range

		dijkstra = new CompetitionDijkstra(filename, 50, 75, 100);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 38;
		assertEquals(correctTestVal, result); // returns correct time, when A is the slowest person

		filename = "1000EWD.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = 28;
		assertEquals(correctTestVal, result); // returns correct time

		filename = "input-A.txt";
		dijkstra = new CompetitionDijkstra(filename, 50, 50, 50);
		result = dijkstra.timeRequiredforCompetition();
		correctTestVal = -1;
		assertEquals(correctTestVal, result); // returns 1
	}

	@Test
	public void testFWConstructor() {
		String filename = "tinyEWD.txt";
		int contestantSpeed = 50;

		CompetitionFloydWarshall floydWarshall = new CompetitionFloydWarshall(filename, contestantSpeed,
				contestantSpeed, contestantSpeed);

		floydWarshall = new CompetitionFloydWarshall("", contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(floydWarshall.distanceTable, null);

		floydWarshall = new CompetitionFloydWarshall(null, contestantSpeed, contestantSpeed, contestantSpeed);
		assertEquals(floydWarshall.distanceTable, null);
	}

	@Test
	public void testTimeRequiredforCompetitionrFW() {
		String filename = "";
		int correctTestVal = -1;
		int result;

		CompetitionFloydWarshall floydWarshall = new CompetitionFloydWarshall(filename, 49, 50, 90);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as empty file string

		filename = "tinyEWD.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 49, 50, 90);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed below range

		floydWarshall = new CompetitionFloydWarshall(filename, 50, 90, 101);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns -1 as speed above range

		floydWarshall = new CompetitionFloydWarshall(filename, 50, 75, 100);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = 38;
		assertEquals(correctTestVal, result); // returns correct time, when A is the slowest person

		floydWarshall = new CompetitionFloydWarshall(filename, 75, 50, 100);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns correct time, when B is the slowest person

		floydWarshall = new CompetitionFloydWarshall(filename, 75, 90, 50);
		result = floydWarshall.timeRequiredforCompetition();
		assertEquals(correctTestVal, result); // returns correct time, when B is the slowest person

		filename = "1000EWD.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 50, 50, 50);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = 28;
		assertEquals(correctTestVal, result); // returns correct time

		filename = "input-A.txt";
		floydWarshall = new CompetitionFloydWarshall(filename, 50, 50, 50);
		result = floydWarshall.timeRequiredforCompetition();
		correctTestVal = -1;
		assertEquals(correctTestVal, result); // returns -1, as there's no path for some of the elements
	}
}
